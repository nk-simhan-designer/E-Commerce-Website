var sidenav = document.querySelector(".side-navbar");
sidenav.style.left = "-60%";
function showNavbar() {
    sidenav.style.left = "0";
}

function closeNavbar() {
    sidenav.style.left = "-60%";
}